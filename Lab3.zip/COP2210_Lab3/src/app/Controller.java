package app;


public class Controller {

    public static void main(String[] args) {

        yourInfoHeader();
        displayHeaderForPartA();

        double radius = 8.25;
        double area = calculateAreaOfCircle(radius);
        displaySingleResult(area , "calculateAreaOfCircle");

        int value1 = 5;
        double value2 = 59.5;
        multipleNumbersIntAndDoubles(value1 , value2);

        calculateAreaOfTriangleWithOutput(36.3 , 18.2);

        double base = 17.16332;
        double height = 20.172391;
        double width = 20.51723;
        System.out.printf("Triangle info-> \t\t base: %.3f \t\t height: %.5f \t area: %.2f \n", base , height , calculateAreaOfTriangle(base , height));
        System.out.printf("Rectangle info-> \t\t height: %.4f \t width: %.1f \t\t area: %.5f\n\n", height , width , calculateAreaOfRectangle(height , width));

        Helper.displayInfo();


        double result = calculateAreaOfCircle(9.3) + calculateAreaOfRectangle(9.4 , 17.2) + calculateAreaOfTriangle(21.5 , 10.3);
        System.out.printf("Value of result: \t\t %.6f\n\n" , result);
        System.out.println();

        Helper.complexArea(4 ,12 , 5);



    }



    public static void yourInfoHeader() {

        System.out.println("=======================================================================================");
        System.out.println("PROGRAMMER: " + "BASSIT ILAHI");
        System.out.println("PANTHER ID: " + "6328318");
        System.out.println();
        System.out.println("CLASS: \t\t COP2210");
        System.out.println("SECTION: \t " + "U01");
        System.out.println("SEMESTER: \t " + "SPRING 2022");
        System.out.println("CLASSTIME: \t " + "T/TH 6:25-9:05PM");
        System.out.println();
        System.out.println("ASSIGNMENT: " + "LAB 3");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other person.");
        System.out.println("=======================================================================================");
        System.out.println();

    }


    public static void displayHeaderForPartA() {

        System.out.println();
        System.out.println("=======================================================================================");
        System.out.println("SECTION Lab3a");
        System.out.println("=======================================================================================");
        System.out.println();
    }


    public static double calculateAreaOfCircle(double radius) {

        double area = Math.PI * (Math.pow(radius , 2));
        return area;

    }


    public static void displaySingleResult(double value , String methodName) {

        System.out.println();
        System.out.println("=======================================================================================");
        System.out.println(methodName);
        System.out.println("=======================================================================================");
        System.out.printf("Value: \t\t\t\t\t %-10.4f ", value);
        System.out.println("\n\n");


    }


    public static void multipleNumbersIntAndDoubles(int firstNumber , double secondNumber) {

        double result = firstNumber * secondNumber;
        System.out.println("multipleNumbersIntAndDouble -> " + firstNumber + ", " + secondNumber);
        System.out.println("firstNumber: \t\t\t " + firstNumber);
        System.out.println("secondNumber: \t\t\t " + secondNumber);
        System.out.println("result: \t\t\t\t " + result);
    }


    public static void calculateAreaOfTriangleWithOutput(double base , double height) {

        double areaOfTriangle = 0.5 * base * height;
        displaySingleResult(areaOfTriangle , "calculateAreaOfTriangleWithOutput");

    }


    public static double calculateAreaOfTriangle(double base , double height) {

        double tArea = 0.5 * base * height;
        return tArea;

    }


    public static double calculateAreaOfRectangle(double height , double width) {

        double rArea = height * width;
        return rArea;

    }




}
