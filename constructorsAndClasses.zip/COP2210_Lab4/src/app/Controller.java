package app;

import vehicle.Car;

public class Controller {


    public static void main (String[] args) {

        yourInfoHeader();

        Car c1 = new Car();
        c1.displayInfo();

        Car.classDisplayInfo();

        Car c2 = new Car("White" , 4);
        c2.displayInfo();

        Car c3 = new Car("Black" , 2);
        c3.displayInfo();

        Car c4 = new Car("Blue" , 4 , 38500 , 10432);
        c4.displayInfo();

        System.out.println();
        System.out.println();
        System.out.println("---------------------------------------------------------------------");
        System.out.println("working with public instance variable");
        System.out.println("---------------------------------------------------------------------");
        System.out.println();

        c2.displayInfo();
        c2.doYouLikeIt = "No";
        c2.displayInfo();

        System.out.println();
        System.out.println();
        System.out.println("---------------------------------------------------------------------");
        System.out.println("working with build-in string method");
        System.out.println("---------------------------------------------------------------------");
        System.out.println();

        System.out.printf("Color of instance c1:\t\t\t\t\t\t %s\n" , c1.getColor());
        System.out.printf("Length of Color of instance:\t\t\t\t %s \n\n" , c1.getColor().length());

        System.out.println("CarID of instance c2: \t\t\t\t\t\t " + c2.getCarID());
        System.out.printf("Index of 'd' of c2's CarId:\t\t\t\t\t %s \n\n" , c2.getCarID().indexOf('d'));


        System.out.println("CarID of instance c2: \t\t\t\t\t\t " + c2.getCarID());
        System.out.printf("Index of the first 'o' of c2's CarID:\t\t %s \n\n" , c2.getCarID().indexOf('o'));

        System.out.println("CarID of instance c2: \t\t\t\t\t\t " + c2.getCarID());
        System.out.printf("Index of the second 'o' of c2's CarID:\t\t %s \n\n" , c2.getCarID().indexOf("o" , 6));

    }


    public static void yourInfoHeader(){

        System.out.println("=====================================================================");
        System.out.println("PROGRAMMER: " + "BASSIT ILAHI");
        System.out.println("PANTHER ID: " + "6328318");
        System.out.println();
        System.out.println("CLASS: \t\t COP2210 ");
        System.out.println("SECTION: \t " + "U01");
        System.out.println("SEMESTER: \t " + "SPRING 2022");
        System.out.println("CLASSTIME: \t " + "T/TH 6:25-9:05PM");
        System.out.println();
        System.out.println("Assignment: " + "Lab 4");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU'S academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other person. ");
        System.out.println("=====================================================================");
        System.out.println();

    }





}
