package app;

import toolkit.ArrayProcessor;
import vehicle.Car;

public class Controller {

    public static void main(String[] args){

        //Step 0
        yourInfoHeader();

        //Step 2
        for (int i=1; i<6; i++){
            int[] a1 = ArrayProcessor.createArrayWithInts(10,-100,1000);
            ArrayProcessor.displayElementsOfIntArray(a1);
            System.out.printf("Array Average: %.1f\n\n", ArrayProcessor.averageOfIntArray(a1));
        }


        //Step 4
        Car[] cars = new Car[15];
        for (int c=0; c < cars.length; c++){
            cars[c] = new Car();

            //Step 5
            cars[c].displayInfo();
        }
        System.out.println();


        //Step 7
        ArrayProcessor.findCarWithBestMPG(cars);
        ArrayProcessor.findCarWithWorstMPG(cars);

        //Step 8
        ArrayProcessor.averageOfCarPrices(cars);


        //Step 9
        System.out.println();
        System.out.println("=========================================================");
        System.out.println("2d Arrays");
        System.out.println("=========================================================");

        int[][] arrayWithinArrayOfInts = { {1}, {1,2}, {1,2,3,}, {1,2,3,4}};
        for (int i=0; i<arrayWithinArrayOfInts.length; i++){
            System.out.print("{ ");
            for (int j=0; j<arrayWithinArrayOfInts[i].length; j++){
                if(j<arrayWithinArrayOfInts[i].length-1){
                    System.out.print(arrayWithinArrayOfInts[i][j] + ", ");
                }else{
                    System.out.print(arrayWithinArrayOfInts[i][j]);
                }
            }
            //Step 10
            System.out.println("} \t Average of Array Entry: " + ArrayProcessor.averageOfIntArray(arrayWithinArrayOfInts[i]));
        }


        //Step 11
        System.out.println();
        System.out.println("=========================================================");
        System.out.println("ArrayProcessor Events");
        System.out.println("=========================================================");
        System.out.println("ArrayProcessor Events: " + ArrayProcessor.getEventsProcessed());

    }

    //Step 0
    public static void  yourInfoHeader(){

        System.out.println("=========================================================");
        System.out.println("PROGRAMMER: " + "BASSIT ILAHI");
        System.out.println("PANTHER ID: " + "6328318");
        System.out.println();
        System.out.println("CLASS: \t\t COP22210 ");
        System.out.println("SECTION: \t " + "U01");
        System.out.println("SEMESTER: \t " + "SPRING 2022");
        System.out.println("CLASSTIME: \t " + "T/TH 6:25-9:05PM");
        System.out.println();
        System.out.println("ASSIGNMENT: " + "LAB 8");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other person.");
        System.out.println("=========================================================");
        System.out.println();

    }
}
