package toolkit;

import vehicle.Car;

import java.util.Random;

public class ArrayProcessor {

    private static int eventsProcessed = 0;

    public static int getEventsProcessed() {
        return eventsProcessed;

    }

    //Step 1
    public static int[] createArrayWithInts(int sizeOfArray, int min, int max) {
        eventsProcessed++;

        Random rndGen = new Random();

        int[] array = new int[sizeOfArray];

        for (int i=0; i<array.length;i++){
            int range = rndGen.nextInt(max - min ) + min;
            array[i] = range;
        }
        return array;

    }

    public static double averageOfIntArray(int[] array){
        eventsProcessed++;

        double sum = 0;
        int counter = 0;

        for (int a=0; a< array.length; a++){
            sum += array[a];
            counter++;
        }
        double avg = sum/counter;
        return avg;
    }


    public static void displayElementsOfIntArray(int[] array){
        eventsProcessed++;

        System.out.println("=========================================================");
        System.out.println("displayElementOfIntArray");
        System.out.println("=========================================================");

        for (int e=0; e<array.length; e++){
            if(e<array.length-1){
                System.out.print(array[e] + ", ");
            }else{
                System.out.print(array[e]);
            }
        }
        System.out.println();

    }


    //Step 6
    public static void findCarWithBestMPG(Car[] cars){
        eventsProcessed++;

        System.out.println("=========================================================");
        System.out.println("findCarWithBestMPG");
        System.out.println("=========================================================");

        Car bestMPG = cars[0];
        for (int m=0; m< cars.length; m++){
            if(bestMPG.getMpg() <= cars[m].getMpg()){
                bestMPG = cars[m];
            }
        }
        bestMPG.displayInfo();
        System.out.println();
    }

    public static void findCarWithWorstMPG(Car[] cars) {
        eventsProcessed++;

        System.out.println("=========================================================");
        System.out.println("findCarWithWorstMPG");
        System.out.println("=========================================================");

        Car worstMPG = cars[0];
        for (int m = 0; m < cars.length; m++) {
            if (worstMPG.getMpg() <= cars[m].getMpg()) {
                worstMPG = cars[m];
            }
        }
        worstMPG.displayInfo();
        System.out.println();
    }


    //Step 8
    public static double averageOfCarPrices(Car[] cars){
        eventsProcessed++;

        double sum=0;
        double counter=0;

        for (int a=0; a<cars.length; a++){
            sum += cars[a].getPrice();
            counter++;
        }
        double avg=sum/counter;
        System.out.printf("Car Average Price: $%.2f\n\n", avg);
        return avg;
    }

}
