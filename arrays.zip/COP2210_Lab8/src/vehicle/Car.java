package vehicle;

import java.util.Random;

//Step 3
public class Car {

    private static final String VIN = "Vin-";
    private static int carID = 1000;

    private static String[] colors = {"White", "Red", "Blue", "Green", "Black"};
    private static int minMpg = 10;
    private static int maxMPG = 50;
    private static int minPrice = 25000;
    private static int maxPrice = 65000;

    protected String vin;
    protected String color;
    protected double mpg;
    protected double price;

    public Car(){
        Random rndGen = new Random();
        color = colors[rndGen.nextInt(5)];
        mpg = rndGen.nextDouble(maxMPG-minMpg+1)+minMpg;
        price = rndGen.nextDouble(maxPrice-minPrice+1)+minPrice;
        vin = VIN + carID;
    }

    public static String[] getColors(){
        return colors;
    }

    public static int getMinMpg() {
        return minMpg;
    }

    public static int getMaxMPG() {
        return maxMPG;
    }

    public static int getMinPrice() {
        return minPrice;
    }

    public static int getMaxPrice() {
        return maxPrice;
    }

    public String getVin() {
        return vin;
    }

    public String getColor() {
        return color;
    }

    public double getMpg() {
        return mpg;
    }

    public double getPrice() {
        return price;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMpg(double mpg) {
        this.mpg = mpg;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void displayInfo(){
        System.out.printf("VIN: %s \t Color: %s \t Price: $%.2f \t MPG: %.2f\n", vin, color, price, mpg);
    }
}
