package things;

public class Item {

    private String name;
    private double price;
    private int discountQuantity;
    private double discount;

    public Item (String name , double price){
        this.name = name;
        this.price = price;
        discountQuantity = 20;
        discount = 0.2;
    }

    public Item (String name , double price , int discountQuantity , double discount){
        this(name , price);
        this.discountQuantity = discountQuantity;
        this.discount = discount;
    }

    public String getName(){return name;}

    public void setName(String name){this.name = name;}

    public double getPrice(){return price;}

    public void setPrice(double price){this.price = price;}

    public int getDiscountQuantity(){return discountQuantity;}

    public void setDiscountQuantity(int discountQuantity){this.discountQuantity = discountQuantity;}

    public double getDiscount(){return discount;}

    public void setDiscountPercentage(double discount){this.discount = discount;}

    public void info (boolean showHeader) {
        if (showHeader == true) {
            System.out.println("-------------------------------------");
            System.out.printf("Info: %s\n" , name);
            System.out.println("-------------------------------------");
        }
            System.out.printf("Name: \t\t\t\t\t %s \n" , name);
            System.out.printf("Price: \t\t\t\t\t %.2f \n" , price);
            System.out.printf("Discount Quantity: \t\t %s \n" , discountQuantity);
            System.out.printf("Discount: \t\t\t\t %.3f \n\n" , discount);
    }


}
