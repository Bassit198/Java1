package app;
import things.Item;

public class Controller {

    public static void main(String[] args) {

        yourInfoHeader();

        Item apple = new Item("Apple" , 1.29);
        apple.info(true);
        apple.info(false);

        Item milk = new Item("Milk" , 5.69 , 25 , 0.153);
        milk.info(true);

        Item water = new Item("Water" , 2.19 , 50 , 0.05);
        water.info(true);


        if (milk.getPrice() > apple.getPrice()){
            System.out.printf("Milk has greater price. Price of Milk: %.2f\n\n" , milk.getPrice());
        }else{
            System.out.printf("Apple has greater or equal price. Price of apple: %.2f\n\n" , apple.getPrice());
        }


        if (apple.getDiscount() < 0.05){
            System.out.printf("Apple discount is less than 0.05. The discount is: %.3f\n" , apple.getDiscount());
        }else if (apple.getDiscount() < 0.10){
            System.out.printf("Apple discount is less than 0.10. The discount is: %.3f\n" , apple.getDiscount());
        }else if (apple.getDiscount() < 0.15){
            System.out.printf("Apple discount is less than 0.15. The discount is: %.3f\n" , apple.getDiscount());
        }else{
            System.out.printf("Apple discount is greater than or equal to 0.15. The discount is: %.3f\n" , apple.getDiscount());
        }


        if ((water.getPrice() >= 3.99) || (apple.getDiscount()) < 0.17) {
            if (milk.getDiscountQuantity() == 18) {
                System.out.println("Milk discount quantity equals 18");
            } else {
                System.out.println("Milk discount quantity low");
            }

        }else if (water.getDiscount() < 0.01){
            System.out.printf("Water discount is less than 0.01. The discount is: %.3f\n" , water.getDiscount());
        }else if (water.getDiscount() < 0.05){
            System.out.printf("Water discount is less than 0.05. The discount is: %.3f\n" , water.getDiscount());
        }else if (water.getDiscount() < 0.15) {
            System.out.printf("Water discount is less than 0.15. The discount is: %.3f\n", water.getDiscount());
        }

    }

    public static void yourInfoHeader(){
        System.out.println("=======================================================================================");
        System.out.println("PROGRAMMER: " + "BASSIT ILAHI");
        System.out.println("PANTHER ID: " + "6328318");
        System.out.println();
        System.out.println("CLASS: \t\t COP2210");
        System.out.println("SECTION: \t " + "U01");
        System.out.println("SEMESTER: \t " + "SPRING 2022");
        System.out.println("CLASSTIME: \t " + "T/TH 6:25-9:05PM");
        System.out.println();
        System.out.println("ASSIGNMENT: " + "LAB 6");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other person.");
        System.out.println("=======================================================================================");
        System.out.println();
    }


}
