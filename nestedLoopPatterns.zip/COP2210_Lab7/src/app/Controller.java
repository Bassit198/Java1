package app;

import java.util.Random;
import java.util.Scanner;

public class Controller {

    public static void main(String[] args) {
        yourInfoHeader();
        pattern1(6,10);
        pattern2("PROGRAMMING");
        pattern3("PROGRAMMING", 6);
        pattern4("CODE", "COP2210");

        //STEP 3
        for (int k=0; k<=14; k++) {
            if (k<14){
                System.out.print(k + ", ");
            }else{
                System.out.println(k);
            }
        }

        System.out.println();


        //STEP 4
        for (int i=-10; i<=11; i+=3) {
            if (i<11){
                System.out.print(i + ", ");
            }else{
                System.out.print(i);
            }
        }

        System.out.println("\n");


        //STEP 5
        for (int j=15; j>=0; j--) {
            if (j<=15 && j>0){
                System.out.print(j + ", ");
            }else{
                System.out.print(j);
            }
        }

        System.out.println("\n");


        //STEP 6
        String str = "Java Programming";
        System.out.println(str);
        for (int a=str.length()-1; a>-1; a--) {
            System.out.print(str.charAt(a));
        }

        System.out.println("\n");

        //STEP 7
        Random rndGen = new Random();
        int maxRndNumber =-100;
        int location = 1;
        for (int i=1; i<=25; i++){
            int currentRandomNumber = rndGen.nextInt(201) - 100;

            if (maxRndNumber < currentRandomNumber){
                maxRndNumber = currentRandomNumber;
                location = i;
            }

            if (i<25){
                System.out.print(currentRandomNumber + ", ");
            }else{
                System.out.print(currentRandomNumber);
            }
        }
        System.out.println("\n");
        System.out.printf("Max Random Number: %d \t at location: %d\n\n" , maxRndNumber , location);


        //STEP 8
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int keyboardInput = sc.nextInt();

        while (keyboardInput < 100) {
            System.out.print("Enter a Number: ");
            keyboardInput = sc.nextInt();
        }
        System.out.println("You are done\n");


        //STEP 9
        Scanner ab = new Scanner(System.in);
        boolean isNotDone = true;

        do {
            System.out.print("Enter a value: ");
            int input = ab.nextInt();

            if (input<50){
                isNotDone = false;
                System.out.print("You are done");
            }

        }while(isNotDone);


    }

    //STEP 10
    public static void pattern1(int numberOfRows, int numberOfCols){
        for (int row=1; row<=6; row++){
            for (int col=1; col<=10; col++){
                if(row%2 == 0 || row%4 == 0){
                    System.out.print("X" + "\t");
                }else{
                    System.out.print("O" + "\t");
                }
            }
            System.out.println();

        }
        System.out.println();
    }


    //STEP 11
    public static void pattern2(String word){
        for (int row=1; row<=8; row++){
            for ( int col=1; col<=17; col++){
                if (col<=3 || col>=15){
                    System.out.print("X ");
                }else{
                    System.out.print(word.charAt(col-4) + " ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }


    ///STEP 12
    public static void pattern3(String word, int numberOfRows) {
        for (int row = 1; row <= numberOfRows; row++) {
            if (row % 2 == 1) {
                for (int col = 1; col <= word.length() + 8; col++) {
                    if (col <= 3 || col >= word.length() + 4) {
                        System.out.print("X ");
                    } else {
                        System.out.print(word.charAt(col-4) + " ");
                    }
                }
                System.out.println();

            }else{
                for (int col = 1; col <= word.length() + 8; col++) {
                    if (col <= 3 || col >= word.length() + 4) {
                        System.out.print("X ");
                    } else {
                        System.out.print(word.charAt(word.length() + 3 - col) + " ");
                    }
                }
                System.out.println();
            }
        }
        System.out.println();
    }

    public static void pattern4(String word1, String word2){
        for (int row = 0; row<=10; row++){
            for (int col = 0; col <= word1.length()+word2.length()-1; col++){
                if(row <= 3 && col <= word1.length()-1){
                    System.out.print("I ");
                }
                if(row >= 4 &&col <= word1.length()-1){
                    System.out.print(word1.charAt(col) + " ");
                }
                if(row<=3 && col >= word1.length()){
                    System.out.print(word2.charAt(col - word1.length()) + " ");
                }
                if(row >= 4 && col >= word1.length()){
                    System.out.print("X ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }



    public static void yourInfoHeader(){

        System.out.println("=========================================================");
        System.out.println("PROGRAMMER: " + "BASSIT ILAHI");
        System.out.println("PANTHER ID: " + "6328318");
        System.out.println();
        System.out.println("CLASS: \t\t COP22210 ");
        System.out.println("SECTION: \t " + "U01");
        System.out.println("SEMESTER: \t " + "SPRING 2022");
        System.out.println("CLASSTIME: \t " + "T/TH 6:25-9:05PM");
        System.out.println();
        System.out.println("ASSIGNMENT: " + "LAB 7");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other person.");
        System.out.println("=========================================================");
        System.out.println();

    }
}
