package app;

public class Controller {
//-------------------------
//MainStart
    public static void main(String[] args){
        yourInfoHeader();

        int minutes = 33;
        int hours = 15;
        int days = 4;

        int secondsInMinute = minutes * 60;
        int secondsInHour = hours * 3600;
        int secondsInDay = days * 86400;

        int totalseconds = secondsInMinute + secondsInHour + secondsInDay;

        printStepHeader(3);
        System.out.printf("Number of seconds in 4 days, 15 hours and 33 minutes is %d \n", totalseconds);

//-------------------------
//Investment and Interest

        printStepHeader(4);

        double initialInvestment = 125000.0;

        double year1InterestRate = 0.05;
        double year2InterestRate = 0.09;
        double year3InterestRate = -0.035;
        double year4InterestRate = 0.07;
        double totalInterestEarned;

        double year1InvestmentValue = (initialInvestment * year1InterestRate) + initialInvestment;
        double year2InvestmentValue = (year1InvestmentValue * year2InterestRate) + year1InvestmentValue;
        double year3InvestmentValue = (year2InvestmentValue * year3InterestRate) + year2InvestmentValue;
        double year4InvestmentValue = (year3InvestmentValue * year4InterestRate) + year3InvestmentValue;
        totalInterestEarned = year4InvestmentValue - initialInvestment;

//-------------------------
//Using PRINTLN

        System.out.println("initialInvestment:\t\t\t\t" + initialInvestment);
        System.out.println("year1InvestmentValue:\t\t\t" + year1InvestmentValue);
        System.out.println("year2InvestmentValue:\t\t\t" + year2InvestmentValue);
        System.out.println("year3InvestmentValue:\t\t\t" + year3InvestmentValue);
        System.out.println("year4InvestmentValue:\t\t\t" + year4InvestmentValue);
        System.out.println("totalInterestEarned: \t\t\t" + totalInterestEarned);
        System.out.println();
//-------------------------

//-------------------------
//Using PRINTF

        System.out.printf("initialInvestment: \t\t\t\t %10.2f \n", initialInvestment);
        System.out.printf("year1InvestmentValue: \t\t\t %10.2f \n", year1InvestmentValue);
        System.out.printf("year2InvestmentValue: \t\t\t %10.2f \n", year2InvestmentValue);
        System.out.printf("year3InvestmentValue: \t\t\t %10.2f \n", year3InvestmentValue);
        System.out.printf("year4InvestmentValue: \t\t\t %10.2f \n", year4InvestmentValue);
        System.out.printf("totalInterestEarned: \t\t\t %10.2f \n", totalInterestEarned);
//------------------------

//------------------------
//Circle Area
        printStepHeader(5);
        double circleDiameter = 17.3543;
        double circleRadius = circleDiameter / 2.0;
        double circleCircumference = 2.0 * Math.PI * circleRadius;
        double circleArea = Math.PI * Math.pow(circleRadius, 2);

        System.out.printf("circleDiameter: \t\t\t\t %-10.4f \n", circleDiameter);
        System.out.printf("circleRadius: \t\t\t\t\t %-10.4f \n", circleRadius);
        System.out.printf("circleCircumference: \t\t\t %-10.4f \n", circleCircumference);
        System.out.printf("circleArea: \t\t\t\t\t %-10.4f \n", circleArea);
//-------------------------

//-------------------------
//Total Area
        printStepHeader(6);
        double rectangleHeight = 19.4;
        double rectangleWidth = 34.7;

        double triangleHeight = 16.4;
        double triangleBase = 20.1;

        double rectanglePerimeter = 2 * (rectangleHeight + rectangleWidth);
        double rectangleArea = rectangleHeight * rectangleWidth;

        double triangleHypotenuse = Math.sqrt(Math.pow(triangleHeight,2) + Math.pow(triangleBase,2));

        double trianglePerimeter = triangleBase + triangleHeight + triangleHypotenuse;
        double triangleArea = (0.5 * triangleHeight) * triangleBase;

        double totalPerimeter = trianglePerimeter + rectanglePerimeter;
        double totalArea = rectangleArea + triangleArea;

        System.out.printf("rectangleHeight: \t\t\t %8.1f \n", rectangleHeight);
        System.out.printf("rectangleWidth: \t\t\t %8.1f \n", rectangleWidth);
        System.out.printf("triangleHeight: \t\t\t %8.1f \n", triangleHeight);
        System.out.printf("rectanglePerimeter: \t\t %8.1f \n", rectanglePerimeter);
        System.out.printf("rectangleArea: \t\t\t\t %8.1f \n", rectangleArea);
        System.out.printf("triangleHypotenuse: \t\t %8.1f \n", triangleHypotenuse);
        System.out.printf("trianglePerimeter: \t\t\t %8.1f \n", trianglePerimeter);
        System.out.printf("triangleArea: \t\t\t\t %8.1f \n", triangleArea);
        System.out.printf("totalPerimeter: \t\t\t %8.1f \n", totalPerimeter);
        System.out.printf("totalArea: \t\t\t\t\t %8.1f \n", totalArea);
//-------------------------

//-------------------------
//Boost
        printStepHeader(7);
        double airFlow = 1.253;
        double x = 1.392;
        double y = 0.72;
        double z = 4.2932;

        double epow = 6 * x * (Math.pow(y,4));
        double insidesRoot1 = 7 * x * (Math.pow(y, 5.23)) * z;
        double lastPow = Math.pow(2, x * y * z);

        double temp1 = Math.cos(Math.pow(airFlow, 3));
        double temp2 = Math.exp(epow);
        double temp3 = 2 * Math.sqrt(insidesRoot1);
        double temp4 = 1.8 * x * y * z;
        double temp5 = Math.pow(0.75, lastPow);
        double temp6 = Math.sqrt(airFlow + x);
        double hard = (temp2 + temp3) / temp6;


        double boost = temp1 * hard + temp4 + temp5;

        System.out.printf("airFlow: \t\t\t\t\t %-8.6f \n", airFlow);
        System.out.printf("x: \t\t\t\t\t\t\t %-8.6f \n", x);
        System.out.printf("y: \t\t\t\t\t\t\t %-8.6f \n", y);
        System.out.printf("z: \t\t\t\t\t\t\t %-8.6f \n", z);
        System.out.printf("temp1: \t\t\t\t\t\t %-8.6f \n", temp1);
        System.out.printf("temp2: \t\t\t\t\t\t %-8.6f \n", temp2);
        System.out.printf("temp3: \t\t\t\t\t\t %-8.6f \n", temp3);
        System.out.printf("temp4: \t\t\t\t\t\t %-8.6f \n", temp4);
        System.out.printf("temp5: \t\t\t\t\t\t %-8.6f \n", temp5);
        System.out.printf("temp6: \t\t\t\t\t\t %-8.6f \n", temp6);
        System.out.printf("boost: \t\t\t\t\t\t %-8.6f \n", boost);


//End Main
    }

    public static void yourInfoHeader(){

        System.out.println("===================================================================");
        System.out.println("PROGRAMMER: " + "BASSIT ILAHI");
        System.out.println("PANTHER ID: " + "6328318");
        System.out.println();
        System.out.println("CLASS: \t\t COP2210 ");
        System.out.println("SECTION: \t " + "U01");
        System.out.println("SEMESTER: \t " + "SPRING 2022");
        System.out.println("CLASSTIME: \t " + "T/TH 6:25-9:05PM");
        System.out.println();
        System.out.println("CERTIFICATION \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it the");
        System.out.println("work of any other person.");
        System.out.println("===================================================================");
        System.out.println();
    }

    public static void printStepHeader(int stepNumber){

        System.out.println();
        System.out.println();
        System.out.println("===================================================================");
        System.out.println("Step: " + stepNumber);
        System.out.println("===================================================================");
    }

}
