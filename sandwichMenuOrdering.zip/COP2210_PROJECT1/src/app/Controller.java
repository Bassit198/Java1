package app;

import food.Apple;
import food.Sandwich;
import machine.Register;
import transactions.Payment;

public class Controller {

    //=============================================================================================
    // PROGRAMMER:      Bassit Ilahi
    // PANTHER ID:      6328318
    //
    // CLASS:           COP2210
    // SECTION:         Your class section: U01
    // SEMESTER:        The current semester: Spring 2022
    // CLASSTIME:       Your COP2210 course meeting time :T/TH 6:25-9:05 pm
    //
    // Project:         Project 1
    // DUE:             April 3rd 2022
    //
    // CERTIFICATION:   I understand FIU’s academic policies, and I certify that this work is my
    //                  own and that none of it is the work of any other person.
    //=============================================================================================

    public static void main(String[] args) {
        System.out.println("===============================================");
        System.out.println("COP 2210 - Project 1 Output");
        System.out.println("Bassit Ilahi");
        System.out.println("6328318");
        System.out.println("U01");
        System.out.println("===============================================");
        System.out.println("\n");

        Register register = new Register(15, 20, 10, 20,
                50);
        register.cashInfo("Manager");
        register.cashInfo("Staff");

        Apple grannySmith = new Apple("Granny Smith", 1.51, 140);
        grannySmith.displayInfo();


        Payment applePayment1 = new Payment(10, 0, 0, 0,
                47);
        applePayment1.displayInfo();

        register.buyApple(grannySmith, applePayment1);

        register.cashInfo("Manager");

        Apple macintosh = new Apple("Macintosh", 1.70, 150);
        macintosh.displayInfo();

        Payment applePayment2 = new Payment(0, 2, 0, 0,
                0);
        applePayment2.displayInfo();

        register.buyApple(macintosh, applePayment2);

        register.cashInfo("Manager");


        Sandwich sandwich = new Sandwich(true, true, true);
        sandwich.displayInfo();

        Payment sandwichPayment1 = new Payment(5, 2, 1, 1,
                2);
        sandwichPayment1.displayInfo();

        register.buySandwich(sandwich, sandwichPayment1);

        register.cashInfo("Manager");





        boolean meat;
        boolean cheese;
        boolean veggies;

        for (int i =1; i<9; i++){

            if(i<=4){
                meat = true;
            }else{
                meat = false;
            }

            if(i<=2 || i==5 || i==6){
                cheese = true;
            }else{
                cheese = false;
            }

            if(i%2==1){
                veggies = true;
            }else{
                veggies = false;
            }

            Sandwich s1 = new Sandwich(meat, cheese, veggies);
            Payment p1 = new Payment(10,0,0,0,
                    0);
            System.out.println("===============================================");
            System.out.println("===============================================");

            s1.displayInfo();
            p1.displayInfo();
            register.buySandwich(s1,p1);
            register.cashInfo("Manager");

        }
    }
}

