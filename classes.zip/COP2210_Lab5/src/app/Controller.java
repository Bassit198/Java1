package app;
import buildingunit.Room;
import cooling.AC;
import building.House;


public class Controller {

    public static void main(String[] args) {

        AC.acStats();

        Room kitchen = new Room("Kitchen", "White", 15.5, 10.0, 78.0);
        kitchen.roomStats("");

        Room livingRoom = new Room("Living Room", "Tan", 25.00, 20.70, 76.50);
        livingRoom.roomStats("");

        Room bathroom = new Room("Bathroom", "White", 15.00, 10.00, 74.30);
        bathroom.roomStats("");

        Room bedroom = new Room("Bedroom", "Blue", 8.00, 8.00, 78.00);
        bedroom.roomStats("");

        House myHouse = new House(kitchen, livingRoom, bathroom, bedroom);
        myHouse.displayInfo();

        System.out.println("--------------------------------------------------");
        System.out.println("What is the house's total square feet: " + myHouse.getHouseSquareFeet());
        System.out.println("--------------------------------------------------");
        System.out.println();

        AC.acStats();

        System.out.println("--------------------------------------------------");
        System.out.println("Call by Value ");
        System.out.println("--------------------------------------------------");
        System.out.println();

        AC.changeTemperatureDown(livingRoom.getTemperature(), 5);

        livingRoom.roomStats("");


        AC.changeTemperatureDown(myHouse.getKitchen().getTemperature(), 3);

        myHouse.getKitchen().roomStats("");

        AC.acStats();


        System.out.println("--------------------------------------------------");
        System.out.println("Call by Reference ");
        System.out.println("--------------------------------------------------");
        System.out.println();

        AC.changeTemperatureDown(livingRoom, 5);
        livingRoom.roomStats("");

        AC.acStats();

        AC.changeTemperatureDown(myHouse.getKitchen(), 3);
        myHouse.getKitchen().roomStats("");

        AC.acStats();

    }
}

    //=============================================================================
    // PROGRAMMER: BASSIT ILAHI
    // PANTHER ID: 6328318

    // CLASS: COP2210
    // SECTION: Your class section: U01
    // SEMESTER: The current semester: Spring 2022
    // CLASSTIME: T/TH 6:25-9:00 pm

    // PROJECT: LAB 5
    // DUE: 02/20/2022

    // CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
    //                own and that none of it is the work of any other person.
    //=============================================================================
