package things;

import java.util.Random;

public class Phone {

    private String number;
    private double price;

    public Phone(String number) {
        this.number = number;

        Random rndGen = new Random();
        this.price=rndGen.nextInt(1300+150)+150 + rndGen.nextDouble();
    }

    public String getNumber() {
        return number;
    }

    public double getPrice() {
        return price;
    }

    public void displayInfo(){
        System.out.printf("type-> Phone->\t\t\t %-18s \t\t Price: %8.2f\n", number, price);
    }
}
