package things;

import java.util.ArrayList;

public class PencilBag {
    ArrayList<Pen> pens;

    public PencilBag(){
        pens = new ArrayList<>();
    }

    public ArrayList<Pen> getPens() {
        return pens;
    }

    public void displayContains(){
        for(Pen pen : pens){
            pen.displayInfo();
        }
    }


}
