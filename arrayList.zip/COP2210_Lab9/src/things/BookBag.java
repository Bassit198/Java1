package things;

import living.Person;
import java.util.ArrayList;


public class BookBag {

    private Person owner;
    private final ArrayList items;

    public BookBag(Person owner, ArrayList items) {
        this.owner = owner;
        this.items = new ArrayList<>();
    }

    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }

    public ArrayList getItems() {
        return items;
    }

    public void displayInfo() {
        for (Object item : items) {
            if(item instanceof Phone) {
                ((Phone) item).displayInfo();
            }else if(item instanceof Book){
                ((Book) item).displayInfo();
            }else if(item instanceof PencilBag){
                for(Pen p1 : ((PencilBag)item).getPens()){
                    p1.displayInfo();
                }
            }
        }
    }
}
