package living;

import things.Book;
import things.BookBag;
import things.Pen;
import things.PencilBag;
import things.Phone;

public class Person {

    private String firstName;
    private String lastName;
    private BookBag bookbag = null;

    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public BookBag getBookbag() {
        return bookbag;
    }

    public void setBookbag(BookBag bookbag) {
        this.bookbag = bookbag;
    }

    public double totalPriceOfPossessions() {
        double totalPrice = 0;

        for (Object price : bookbag.getItems()) {
            if (price instanceof Phone) {
                totalPrice += ((Phone) price).getPrice();
            }if (price instanceof Book) {
                totalPrice += ((Book) price).getPrice();
            }if (price instanceof PencilBag) {
                for (Pen p1 : (((PencilBag) price).getPens())) {
                    totalPrice += p1.getPrice();
                }
            }


        }

        return totalPrice;
    }
}

