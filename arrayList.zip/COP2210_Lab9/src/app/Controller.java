package app;

import living.Person;
import things.*;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Random;

public class Controller {

    public static void main(String[] args) {

        yourInfoHeader();

        Person person = new Person("Mike", "Johnson");
        BookBag bookBag = new BookBag(person, new ArrayList<>());
        person.setBookbag(bookBag);

        Random rndGen = new Random();
        for (int i = 1; i < 6; i++) {
            int areaCode = rndGen.nextInt(999 - 100) + 100;
            int threeDigit = rndGen.nextInt(999 - 100) + 100;
            int fourDigit = rndGen.nextInt(9999 - 1000) + 1000;
            String phoneNumber = "(" + areaCode + ")-" + threeDigit + "-" + fourDigit;

            Phone phone = new Phone(phoneNumber);
            bookBag.getItems().add(phone);
        }

        String[] subject = new String[]{"Math", "Chemistry", "CS", "Physics", "History"};
        for (int i = 1; i < 5; i++) {
            String subjectRan = subject[(rndGen.nextInt(subject.length))];
            double price = (double) (rndGen.nextInt(200 - 50) + 50 + rndGen.nextDouble());

            Book book = new Book(subjectRan, price);
            bookBag.getItems().add(book);
        }

        PencilBag pencilBag = new PencilBag();
        bookBag.getItems().add(pencilBag);

        String[] colors = new String[]{"Red", "Black", "Green", "Blue"};
        for (int i = 1; i < 6; i++) {
            String color = colors[(rndGen.nextInt(colors.length))];
            double price1 = (double) (rndGen.nextInt(4 - 1) + 1 + rndGen.nextDouble());

            Pen pen = new Pen(color, price1);

            pencilBag.getPens().add(pen);
        }


        bookBag.displayInfo();





        System.out.println();
        System.out.println("----------------------------------------------------------------------------");
        System.out.println("Total Price of Possessions");
        System.out.println("----------------------------------------------------------------------------");
        System.out.printf("Total: $%.2f\n", person.totalPriceOfPossessions());

    }



    public static void yourInfoHeader() {
        System.out.println("============================================================================");
        System.out.println("PROGRAMMER: " + "Bassit Ilahi");
        System.out.println("PANTHER ID: " + "6328318");
        System.out.println();
        System.out.println("CLASS: \t\t" + "COP2210");
        System.out.println("SECTION: \t" + "U01");
        System.out.println("SEMESTER: \t" + "SPRING 2022");
        System.out.println("CLASSTIME: \t" + "T/TH 6:25-9:05PM");
        System.out.println();
        System.out.println("Assignment: " + "LAB 9");
        System.out.println();
        System.out.println("CERTIFICATION: \nI understand FIU's academic policies, and I certify");
        System.out.println("that this work is my own and that none of it is the");
        System.out.println("work of any other person.");
        System.out.println("============================================================================");
        System.out.println();

    }
}
